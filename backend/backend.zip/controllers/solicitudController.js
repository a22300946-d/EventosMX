const Solicitud = require('../models/Solicitud');
const Mensaje = require('../models/Mensaje');
const Calendario = require('../models/Calendario');

// Importar socket de forma segura
let emitNotification;
try {
  const socketConfig = require('../config/socket');
  emitNotification = socketConfig.emitNotification;
} catch (error) {
  console.warn('⚠️ Socket.IO no disponible, notificaciones deshabilitadas');
  emitNotification = () => {}; // Función vacía como fallback
}

// ✅ Función helper para formatear fechas sin desfase de zona horaria
const formatearFechaSinDesfase = (fechaString) => {
  if (!fechaString) return 'Fecha no especificada';
  
  // Extraer componentes de la fecha
  const fecha = new Date(fechaString);
  const year = fecha.getUTCFullYear();
  const month = fecha.getUTCMonth();
  const day = fecha.getUTCDate();
  
  // Crear fecha en hora local
  const fechaLocal = new Date(year, month, day);
  
  return fechaLocal.toLocaleDateString('es-MX', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

// Crear nueva solicitud (cliente)
const crearSolicitud = async (req, res) => {
  try {
    const id_cliente = req.usuario.id;
    const { 
      id_proveedor, 
      fecha_evento, 
      numero_invitados,
      tipo_evento, 
      presupuesto_estimado, 
      descripcion_solicitud,
      servicios_solicitados 
    } = req.body;

    // Validar campos requeridos
    if (!id_proveedor || !fecha_evento || !tipo_evento) {
      return res.status(400).json({
        success: false,
        message: 'Proveedor, fecha del evento y tipo de evento son obligatorios'
      });
    }

    // Validar que la fecha del evento sea futura
    const fechaEvento = new Date(fecha_evento);
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);

    if (fechaEvento < hoy) {
      return res.status(400).json({
        success: false,
        message: 'La fecha del evento debe ser futura'
      });
    }

    // ✅ NUEVO: Validar presupuesto máximo
    if (presupuesto_estimado) {
      const presupuesto = parseFloat(presupuesto_estimado);
      if (presupuesto > 99999999.99) {
        return res.status(400).json({
          success: false,
          message: 'El presupuesto máximo permitido es $99,999,999.99'
        });
      }
      if (presupuesto < 0) {
        return res.status(400).json({
          success: false,
          message: 'El presupuesto no puede ser negativo'
        });
      }
    }

    // ✅ NUEVO: Validar número de invitados
    if (numero_invitados) {
      const invitados = parseInt(numero_invitados);
      if (invitados < 1) {
        return res.status(400).json({
          success: false,
          message: 'El número de invitados debe ser al menos 1'
        });
      }
      if (invitados > 999999) {
        return res.status(400).json({
          success: false,
          message: 'El número de invitados es demasiado grande'
        });
      }
    }

    // Validar servicios si se proporcionan
    if (servicios_solicitados && !Array.isArray(servicios_solicitados)) {
      return res.status(400).json({
        success: false,
        message: 'Los servicios solicitados deben ser un array'
      });
    }

    // Crear la solicitud
    const nuevaSolicitud = await Solicitud.crear({
      id_cliente,
      id_proveedor,
      fecha_evento,
      numero_invitados,
      tipo_evento,
      presupuesto_estimado,
      descripcion_solicitud,
      servicios_solicitados 
    });

    // ✅ CREAR MENSAJE AUTOMÁTICO CON INFORMACIÓN DE LA SOLICITUD
    try {
      const mensajeInicial = `📋 Nueva solicitud de cotización

🎉 Tipo de evento: ${tipo_evento}
📅 Fecha: ${formatearFechaSinDesfase(fecha_evento)}
${numero_invitados ? `👥 Número de invitados: ${numero_invitados}` : ''}
${presupuesto_estimado ? `💰 Presupuesto estimado: $${parseFloat(presupuesto_estimado).toLocaleString('es-MX')}` : ''}
${descripcion_solicitud ? `\n📝 Detalles adicionales:\n${descripcion_solicitud}` : ''}

¡Hola! Estoy interesado en tus servicios para mi evento. ¿Podrías enviarme una cotización?`;

      console.log('📝 Intentando crear mensaje inicial para solicitud:', nuevaSolicitud.id_solicitud);
      
      await Mensaje.crear({
        id_solicitud: nuevaSolicitud.id_solicitud,
        id_remitente: id_cliente,
        tipo_remitente: 'cliente',
        contenido: mensajeInicial
      });

      console.log('✅ Mensaje inicial creado exitosamente');
    } catch (errorMensaje) {
      console.error('❌ Error al crear mensaje inicial:', errorMensaje);
      console.error('Stack:', errorMensaje.stack);
      // No fallar la solicitud si el mensaje falla
    }

    // Emitir notificación por Socket.IO al proveedor
    try {
      emitNotification(id_proveedor, 'proveedor', 'nueva_solicitud', {
        id_solicitud: nuevaSolicitud.id_solicitud,
        mensaje: 'Nueva solicitud de cotización recibida',
        tipo_evento,
        fecha_evento
      });
    } catch (errorSocket) {
      console.error('❌ Error al emitir notificación Socket.IO:', errorSocket);
      // No fallar la solicitud si la notificación falla
    }

    res.status(201).json({
      success: true,
      message: 'Solicitud creada exitosamente',
      data: nuevaSolicitud
    });

  } catch (error) {
    console.error('Error al crear solicitud:', error);
    res.status(500).json({
      success: false,
      message: 'Error al crear la solicitud',
      error: error.message
    });
  }
};

// Obtener solicitudes del cliente autenticado
const obtenerMisSolicitudes = async (req, res) => {
  try {
    const id_cliente = req.usuario.id;
    const { estado, limite } = req.query;

    const solicitudes = await Solicitud.obtenerPorCliente(id_cliente, {
      estado,
      limite: limite ? parseInt(limite) : null
    });

    res.json({
      success: true,
      data: solicitudes,
      total: solicitudes.length
    });

  } catch (error) {
    console.error('Error en obtenerMisSolicitudes:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener solicitudes',
      error: error.message
    });
  }
};

// Obtener solicitudes recibidas por el proveedor
const obtenerSolicitudesRecibidas = async (req, res) => {
  try {
    const id_proveedor = req.usuario.id;
    const { estado, limite } = req.query;

    const solicitudes = await Solicitud.obtenerPorProveedor(id_proveedor, {
      estado,
      limite: limite ? parseInt(limite) : null
    });

    res.json({
      success: true,
      data: solicitudes,
      total: solicitudes.length
    });

  } catch (error) {
    console.error('Error en obtenerSolicitudesRecibidas:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener solicitudes',
      error: error.message
    });
  }
};

// Obtener detalle de una solicitud
const obtenerSolicitudPorId = async (req, res) => {
  try {
    const { id } = req.params;
    const usuario = req.usuario;

    const solicitud = await Solicitud.obtenerPorId(id);

    if (!solicitud) {
      return res.status(404).json({
        success: false,
        message: 'Solicitud no encontrada'
      });
    }

    // Verificar que el usuario tenga permiso para ver esta solicitud
    const tienePermiso = 
      (usuario.tipo === 'cliente' && solicitud.id_cliente === usuario.id) ||
      (usuario.tipo === 'proveedor' && solicitud.id_proveedor === usuario.id);

    if (!tienePermiso) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para ver esta solicitud'
      });
    }

    res.json({
      success: true,
      data: solicitud
    });

  } catch (error) {
    console.error('Error en obtenerSolicitudPorId:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener solicitud',
      error: error.message
    });
  }
};

// Responder solicitud con propuesta (proveedor)
const responderSolicitud = async (req, res) => {
  try {
    const id_proveedor = req.usuario.id;
    const { id } = req.params;
    const { 
      mensaje_respuesta, 
      precio_propuesto, 
      detalles_servicio,
      fecha_disponible 
    } = req.body;

    console.log('📋 responderSolicitud - Datos recibidos:', {
      id_solicitud: id,
      id_proveedor,
      body: req.body
    });

    // Validar campos requeridos
    if (!mensaje_respuesta || !precio_propuesto) {
      console.log('❌ Validación falló - Campos faltantes');
      return res.status(400).json({
        success: false,
        message: 'Mensaje de respuesta y precio propuesto son obligatorios'
      });
    }

    // Primero verificar que la solicitud existe y pertenece a este proveedor
    const solicitudExistente = await Solicitud.obtenerPorId(id);
    
    console.log('📋 Solicitud existente:', {
      encontrada: !!solicitudExistente,
      estado: solicitudExistente?.estado,
      id_proveedor: solicitudExistente?.id_proveedor,
      match: solicitudExistente?.id_proveedor === id_proveedor
    });
    
    if (!solicitudExistente) {
      return res.status(404).json({
        success: false,
        message: 'Solicitud no encontrada'
      });
    }

    if (solicitudExistente.id_proveedor !== id_proveedor) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para responder esta solicitud'
      });
    }

    // ✅ PERMITIR RESPONDER SI NO ESTÁ ACEPTADA
    if (solicitudExistente.estado === 'Aceptada') {
      console.log('❌ Solicitud ya aceptada, no se puede modificar');
      return res.status(400).json({
        success: false,
        message: 'No se puede modificar una solicitud ya aceptada'
      });
    }

    const solicitudActualizada = await Solicitud.responderConPropuesta(
      id,
      id_proveedor,
      {
        mensaje_respuesta,
        precio_propuesto,
        detalles_servicio,
        fecha_disponible
      }
    );

    res.json({
      success: true,
      message: 'Propuesta enviada exitosamente al cliente',
      data: solicitudActualizada
    });

  } catch (error) {
    console.error('Error en responderSolicitud:', error);
    res.status(500).json({
      success: false,
      message: 'Error al responder solicitud',
      error: error.message
    });
  }
};

// Aceptar propuesta del proveedor (cliente)
const aceptarSolicitud = async (req, res) => {
  try {
    const id_cliente = req.usuario.id;
    const { id } = req.params;

    // Verificar que la solicitud existe
    const solicitudExistente = await Solicitud.obtenerPorId(id);
    
    console.log('🔍 DEBUG - solicitudExistente COMPLETO:', JSON.stringify(solicitudExistente, null, 2));
    
    if (!solicitudExistente) {
      return res.status(404).json({
        success: false,
        message: 'Solicitud no encontrada'
      });
    }

    if (solicitudExistente.id_cliente !== id_cliente) {
      return res.status(403).json({
        success: false,
        message: 'No tienes permiso para aceptar esta solicitud'
      });
    }

    console.log('🔍 Validando estado:', {
      estado_actual: solicitudExistente.estado,
      tipo: typeof solicitudExistente.estado,
      longitud: solicitudExistente.estado?.length,
      comparacion: solicitudExistente.estado === 'Respondida',
      trim: solicitudExistente.estado?.trim(),
      trim_comparacion: solicitudExistente.estado?.trim() === 'Respondida'
    });

    if (solicitudExistente.estado?.trim() !== 'Respondida') {
      console.log('❌ Estado no válido para aceptar');
      return res.status(400).json({
        success: false,
        message: `Solo se pueden aceptar solicitudes que han sido respondidas por el proveedor. Estado actual: "${solicitudExistente.estado}"`
      });
    }

    // Actualizar estado de la solicitud a Aceptada
    const solicitudActualizada = await Solicitud.actualizarEstado(
      id, 
      'Aceptada', 
      id_cliente, 
      'cliente'
    );

    // ✅ BLOQUEAR AUTOMÁTICAMENTE LA FECHA EN EL CALENDARIO DEL PROVEEDOR
    // La fecha_evento ya fue actualizada cuando el proveedor respondió con su propuesta
    try {
      if (solicitudExistente.fecha_evento) {
        console.log('📅 Bloqueando fecha en calendario:', {
          fecha: solicitudExistente.fecha_evento,
          proveedor: solicitudExistente.id_proveedor,
          solicitud: id
        });
        
        await Calendario.marcarNoDisponible(
          solicitudExistente.id_proveedor,
          solicitudExistente.fecha_evento,
          `Evento: ${solicitudExistente.tipo_evento} - ${solicitudExistente.cliente_nombre || 'Cliente'}`,
          id
        );
        
        console.log('✅ Fecha bloqueada en calendario');
      }
    } catch (errorCalendario) {
      console.error('❌ Error al bloquear fecha en calendario:', errorCalendario);
      // No fallar la aceptación si el calendario falla
    }

    res.json({
      success: true,
      message: 'Propuesta aceptada. Se enviará confirmación por correo a ambas partes.',
      data: solicitudActualizada
    });

  } catch (error) {
    console.error('❌ Error en aceptarSolicitud:', error);
    console.error('Stack trace:', error.stack);
    res.status(500).json({
      success: false,
      message: 'Error al aceptar solicitud',
      error: error.message,
      details: error.stack
    });
  }
};

// Rechazar solicitud (cliente o proveedor)
const rechazarSolicitud = async (req, res) => {
  try {
    const usuario = req.usuario;
    const { id } = req.params;

    const solicitudActualizada = await Solicitud.actualizarEstado(
      id, 
      'Rechazada', 
      usuario.id, 
      usuario.tipo
    );

    if (!solicitudActualizada) {
      return res.status(404).json({
        success: false,
        message: 'Solicitud no encontrada o no tienes permiso'
      });
    }

    res.json({
      success: true,
      message: 'Solicitud rechazada',
      data: solicitudActualizada
    });

  } catch (error) {
    console.error('Error en rechazarSolicitud:', error);
    res.status(500).json({
      success: false,
      message: 'Error al rechazar solicitud',
      error: error.message
    });
  }
};

// Cancelar solicitud (solo cliente y solo si está Pendiente)
const cancelarSolicitud = async (req, res) => {
  try {
    const id_cliente = req.usuario.id;
    const { id } = req.params;

    const solicitudEliminada = await Solicitud.eliminar(id, id_cliente);

    if (!solicitudEliminada) {
      return res.status(404).json({
        success: false,
        message: 'Solicitud no encontrada o no se puede cancelar (solo solicitudes pendientes)'
      });
    }

    res.json({
      success: true,
      message: 'Solicitud cancelada exitosamente'
    });

  } catch (error) {
    console.error('Error en cancelarSolicitud:', error);
    res.status(500).json({
      success: false,
      message: 'Error al cancelar solicitud',
      error: error.message
    });
  }
};

// Obtener estadísticas de solicitudes (para el dashboard)
const obtenerEstadisticas = async (req, res) => {
  try {
    const usuario = req.usuario;
    
    let estadisticas;

    if (usuario.tipo === 'cliente') {
      const todasSolicitudes = await Solicitud.obtenerPorCliente(usuario.id);
      
      estadisticas = {
        total: todasSolicitudes.length,
        pendientes: todasSolicitudes.filter(s => s.estado === 'Pendiente').length,
        respondidas: todasSolicitudes.filter(s => s.estado === 'Respondida').length,
        aceptadas: todasSolicitudes.filter(s => s.estado === 'Aceptada').length,
        rechazadas: todasSolicitudes.filter(s => s.estado === 'Rechazada').length
      };
    } else if (usuario.tipo === 'proveedor') {
      const todasSolicitudes = await Solicitud.obtenerPorProveedor(usuario.id);
      
      estadisticas = {
        total: todasSolicitudes.length,
        pendientes: todasSolicitudes.filter(s => s.estado === 'Pendiente').length,
        respondidas: todasSolicitudes.filter(s => s.estado === 'Respondida').length,
        aceptadas: todasSolicitudes.filter(s => s.estado === 'Aceptada').length,
        rechazadas: todasSolicitudes.filter(s => s.estado === 'Rechazada').length
      };
    }

    res.json({
      success: true,
      data: estadisticas
    });

  } catch (error) {
    console.error('Error en obtenerEstadisticas:', error);
    res.status(500).json({
      success: false,
      message: 'Error al obtener estadísticas',
      error: error.message
    });
  }
};

module.exports = {
  crearSolicitud,
  obtenerMisSolicitudes,
  obtenerSolicitudesRecibidas,
  obtenerSolicitudPorId,
  responderSolicitud,
  aceptarSolicitud,
  rechazarSolicitud,
  cancelarSolicitud,
  obtenerEstadisticas
};