import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import RoleBasedGuestRoute from "./components/RoleBasedGuestRoute";

import VerificarCorreo from "./pages/VerificarCorreo";

// Páginas públicas
import Home from "./pages/Home";
import Login from "./pages/Login";
import LoginProveedor from "./pages/LoginProveedor";
import Register from "./pages/Register";
import RegisterProveedor from "./pages/RegisterProveedor";

// Páginas de cliente
import ExplorarServicios from "./pages/cliente/ExplorarServicios";
import HistorialSolicitudes from "./pages/cliente/HistorialSolicitudes";
import EditarDatos from "./pages/cliente/EditarDatos";
import MisListas from "./pages/cliente/MisListas";
import Preferencias from "./pages/cliente/Preferencias";
import ResenasPublicadas from "./pages/cliente/ResenasPublicadas";
import PerfilProveedor from "./pages/cliente/PerfilProveedor";
import DetallesLista from "./pages/cliente/DetallesLista";
import Favoritos from "./pages/cliente/Favoritos";

// Páginas de proveedor
import MiInformacion from "./pages/proveedor/MiInformacion";
import ServiciosPrecios from "./pages/proveedor/ServiciosPrecios";
import GaleriaFotos from "./pages/proveedor/GaleriaFotos";
import Promociones from "./pages/proveedor/Promociones";
import CalendarioDisponibilidad from "./pages/proveedor/CalendarioDisponibilidad";
import SolicitudesRecibidas from "./pages/proveedor/SolicitudesRecibidas";
import ResenasCalificaciones from "./pages/proveedor/ResenasCalificaciones";

// Páginas de administrador
import RegistroUsuarios from "./pages/admin/RegistroUsuarios";
import RegistroProveedores from "./pages/admin/RegistroProveedores";
import SolicitudesProveedores from "./pages/admin/SolicitudesProveedores";
import ModerarResenas from "./pages/admin/ModerarResenas";
import NotificacionesGenerales from "./pages/admin/NotificacionesGenerales";
import GestionCatalogos from "./pages/admin/GestionCatalogos";

// Página de chat
import Chat from "./pages/chat/Chat";

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Ruta principal */}
          <Route
            path="/"
            element={
              <RoleBasedGuestRoute blockProveedores={true}>
                <Home />
              </RoleBasedGuestRoute>
            }
          />

          {/* Perfil proveedor */}
          <Route
            path="/perfil-proveedor/:id"
            element={
              <ProtectedRoute requiredRole="cliente">
                <PerfilProveedor />
              </ProtectedRoute>
            }
          />

          {/* Auth cliente */}
          <Route
            path="/login"
            element={
              <RoleBasedGuestRoute allowedFor="cliente">
                <Login />
              </RoleBasedGuestRoute>
            }
          />
          <Route
            path="/register"
            element={
              <RoleBasedGuestRoute allowedFor="cliente">
                <Register />
              </RoleBasedGuestRoute>
            }
          />

          {/* Auth proveedor */}
          <Route
            path="/login-proveedor"
            element={
              <RoleBasedGuestRoute allowedFor="proveedor">
                <LoginProveedor />
              </RoleBasedGuestRoute>
            }
          />
          <Route
            path="/register-proveedor"
            element={
              <RoleBasedGuestRoute allowedFor="proveedor">
                <RegisterProveedor />
              </RoleBasedGuestRoute>
            }
          />

          {/* Verificación */}
          <Route path="/verificar-correo" element={<VerificarCorreo />} />

          {/* Cliente */}
          <Route
            path="/cliente/explorar"
            element={
              <ProtectedRoute requiredRole="cliente">
                <ExplorarServicios />
              </ProtectedRoute>
            }
          />
          <Route
            path="/cliente/cuenta/historial"
            element={
              <ProtectedRoute requiredRole="cliente">
                <HistorialSolicitudes />
              </ProtectedRoute>
            }
          />
          <Route
            path="/cliente/cuenta/datos"
            element={
              <ProtectedRoute requiredRole="cliente">
                <EditarDatos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/cliente/cuenta/listas"
            element={
              <ProtectedRoute requiredRole="cliente">
                <MisListas />
              </ProtectedRoute>
            }
          />
          <Route
            path="/cliente/cuenta/preferencias"
            element={
              <ProtectedRoute requiredRole="cliente">
                <Preferencias />
              </ProtectedRoute>
            }
          />
          <Route
            path="/cliente/cuenta/resenas"
            element={
              <ProtectedRoute requiredRole="cliente">
                <ResenasPublicadas />
              </ProtectedRoute>
            }
          />
          <Route path="/cliente/listas" element={<MisListas />} />
          <Route path="/cliente/listas/:id" element={<DetallesLista />} />
          <Route path="/cliente/favoritos" element={<Favoritos />} />

          {/* Proveedor */}
          <Route
            path="/proveedor/cuenta/informacion"
            element={
              <ProtectedRoute requiredRole="proveedor">
                <MiInformacion />
              </ProtectedRoute>
            }
          />
          <Route
            path="/proveedor/cuenta/servicios"
            element={
              <ProtectedRoute requiredRole="proveedor">
                <ServiciosPrecios />
              </ProtectedRoute>
            }
          />
          <Route
            path="/proveedor/cuenta/galeria"
            element={
              <ProtectedRoute requiredRole="proveedor">
                <GaleriaFotos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/proveedor/cuenta/promociones"
            element={
              <ProtectedRoute requiredRole="proveedor">
                <Promociones />
              </ProtectedRoute>
            }
          />
          <Route
            path="/proveedor/cuenta/calendario"
            element={
              <ProtectedRoute requiredRole="proveedor">
                <CalendarioDisponibilidad />
              </ProtectedRoute>
            }
          />
          <Route
            path="/proveedor/cuenta/solicitudes"
            element={
              <ProtectedRoute requiredRole="proveedor">
                <SolicitudesRecibidas />
              </ProtectedRoute>
            }
          />
          <Route
            path="/proveedor/cuenta/resenas"
            element={
              <ProtectedRoute requiredRole="proveedor">
                <ResenasCalificaciones />
              </ProtectedRoute>
            }
          />

          {/* Admin */}
          <Route
            path="/admin/dashboard"
            element={<Navigate to="/admin/usuarios" replace />}
          />
          <Route
            path="/admin/usuarios"
            element={
              <ProtectedRoute requiredRole="admin">
                <RegistroUsuarios />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/proveedores"
            element={
              <ProtectedRoute requiredRole="admin">
                <RegistroProveedores />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/solicitudes"
            element={
              <ProtectedRoute requiredRole="admin">
                <SolicitudesProveedores />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/resenas"
            element={
              <ProtectedRoute requiredRole="admin">
                <ModerarResenas />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/notificaciones"
            element={
              <ProtectedRoute requiredRole="admin">
                <NotificacionesGenerales />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/catalogos"
            element={
              <ProtectedRoute requiredRole="admin">
                <GestionCatalogos />
              </ProtectedRoute>
            }
          />

          {/* Chat */}
          <Route path="/chat" element={<Chat />} />
          <Route path="/chat/:id_solicitud" element={<Chat />} />

          {/* 404 */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;